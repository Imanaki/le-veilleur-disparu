Fichier audio utilisé par l’archive 03 : MORSE.wav
